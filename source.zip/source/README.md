# Pose-Evaluation-Project
## Setup
Mit Python 3.8-11 installiert, öffne ein Terminal und gib nacheinander `pip install mediapipe` und `pip install websocket-server` ein.
Führe entweder main.py und PoseEval 0.X.exe zusammen oder nur PoseEval 0.X standalone aus.
Das Repository liegt unter https://github.com/Leoronus/Pose-Evaluation-Project.
